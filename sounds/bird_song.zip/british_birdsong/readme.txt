Transcriptions of birdsong into midi using Fractal Tune Smithy.

For original sound clips see
European Birds, songs and sonograms:
http://www-stat.wharton.upenn.edu/~siler/masi/eurosongs3.html

Robert Walker, July 2001
robert_walker@rcwalker.freeserve.co.uk